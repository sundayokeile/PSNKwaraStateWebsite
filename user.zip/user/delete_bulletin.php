<?php 
	require_once('admin_session.php');
	require_once('db_connection.php');
	
	$img_bulletin= $_GET['img_bulletin'];
	//echo $name;
	
	$res=mysqli_query($db, "SELECT img_bulletin FROM tbl_bulletin WHERE img_bulletin='$img_bulletin'");
	
	$row=mysqli_fetch_array($res);
	
	mysqli_query($db, "DELETE FROM tbl_bulletin WHERE img_bulletin='$img_bulletin'");
	
	unlink($img_bulletin);
	
	header("Location:bulletin.php");
?>