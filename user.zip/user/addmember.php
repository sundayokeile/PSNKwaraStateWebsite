<?php 
	require_once('admin_session.php');
	require_once('db_connection.php');
	$sql2 = "select * from tbl_admin where username != 'suntosolutions'";
	$sql2 .= " order by username desc";
	$sql_query = mysqli_query($db, $sql2);
?>
<!DOCTYPE html>
<html>
    
    <head>
        <title>New Member</title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <link href="assets/DT_bootstrap.css" rel="stylesheet" media="screen">
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="vendors/flot/excanvas.min.js"></script><![endif]-->
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
    
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="#">NEW MEMBER</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> <?php echo strtoupper($_SESSION['orukonla']); ?> <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="logout.php">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
                            
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Payment <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Something</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">something</a>

                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">Payment History</a>
                                    </li>
                                    
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Members <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="dir_member.php">Member List</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">Something</a>
                                    </li>
                                    
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse"><li>
                            <a href="dir_member.php"><i class="icon-chevron-right"></i> Member Directory</a>
                        </li>
                        <li>
                            <a href="dir_dues.php"><i class="icon-chevron-right"></i> Payment History</a>
                        </li>
                        <li class="active">
                            <a href="#"><i class="icon-chevron-right"></i> Manage Admin Account</a>
                        </li>  
                        <li>
                            <a href="mimeupload.php"><!--span class="badge badge-success pull-right">731</span--> Minutes of Meeting</a>
                        </li>
                         <li>
                            <a href="bulletin.php"> Add News Bulletin</a>
                        </li>
                        <li>
                            <a href="logout.php"><i class="icon-chevron-right"></i> Logout</a>
                        </li>
                    </ul>
                </div>
                <!--/span-->
                <div class="span9" id="content">
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">ADD NEW MEMBER...</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                	<!-- BEGIN FORM-->
                                    <!--php script begins-->
									<?php
                                        // define variables and set to empty values
                                        $username = $password = "";
                                        function test_input($data)
                                        {
                                            $data = trim($data);
                                            $data = stripslashes($data);
                                            $data = htmlspecialchars($data);
                                            return $data;
                                        }
                                        if(isset($_POST['add']))
                                        {
											$title = test_input($_POST["title"]);
											$surname = test_input($_POST["surname"]);
											$firstname = test_input($_POST["firstname"]);
											$lastname = test_input($_POST["lastname"]);
											$pcnregno = test_input($_POST["pcnregno"]);
											$username = test_input($_POST["username"]);
											$password = test_input($_POST["password"]);
											
											$phoneno = $homeaddress = $officeaddress = $sex = $dateofbirth = $maritalstatus = $wedanni = $alternateno = $email = $technicalgroup = $interestgroup = $schoolattended = $yearofgraduation = "nil";
										
											date_default_timezone_set("Africa/Lagos"); 
                                    		$date = date('d/m/Y');
											
											$select = mysqli_query($db, "SELECT * FROM tbl_member");
											$count_row = mysqli_num_rows($select);
                                            $compare = mysqli_query($db, "SELECT username, pcnregno FROM tbl_member WHERE username = '$username' OR pcnregno = '$pcnregno'");
                                            if ($row = $compare->fetch_assoc())
                                            {
                                                $msg =  "Member Already Exist!";
                                            }
                                            else// if record not found, insert new member...
                                            {
												// kindly insert if all is cool..
                                                $insert = "INSERT INTO tbl_member VALUES('$title', '$surname', '$firstname', '$lastname', '$sex', '$dateofbirth', '$maritalstatus', '$wedanni', '$homeaddress', '$officeaddress', '$phoneno', '$alternateno', '$email', '$technicalgroup', '$interestgroup', '$pcnregno', '$schoolattended', '$yearofgraduation', '$username', '$password', '$date')";
												if($db->query($insert) === TRUE)
												{
													$msg = "New Account Created!";
												}
												else
                                                {
													$msg =  "Error: " . $insert . "<br>" . $db->error;
												}
											}
											$db->close();
										}
                                    ?>
                                    <!--php script end-->
                                    <?php 
										if(isset($_POST['add']))
										{
											echo "<div class='alert alert-success' role='alert'>
													$msg
												</div>";
										}
									?>	
  									<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" class="form-horizontal" enctype="multipart/form-data">
                                    	<div class="control-group">
                                        	<label class="control-label" for="focusedInput">Title</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="title" type="text" required>
                                            </div>
                                        </div>
                                    	<div class="control-group">
                                        	<label class="control-label" for="focusedInput">Surname</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="surname" type="text" required>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                        	<label class="control-label" for="focusedInput">Firstname</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="firstname" type="text" required>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                        	<label class="control-label" for="focusedInput">Lastname</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="lastname" type="text" required>
                                            </div>
                                        </div>
                                    	<div class="control-group">
                                        	<label class="control-label" for="focusedInput">Username</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="username" type="text" required>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                        	<label class="control-label" for="focusedInput">Password</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="password" type="text" required>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                        	<label class="control-label" for="focusedInput">PCN.RegNo</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="pcnregno" type="text" required>
                                            </div>
                                        </div>             
                                        <div class="form-actions">
                                        	<button type="submit" name="add" class="btn btn-primary">ADD MEMBER</button>
                                            <button type="reset" class="btn">Cancel</button>
                                        </div>
                                        </fieldset>
                                    </form>
                                    <!-- END FORM-->
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
            <hr>
            <footer>
                <p>&copy; <?php  date_default_timezone_set("Africa/Lagos");echo date('Y'); ?>. All Rights Reserved | PSN KWARA STATE</p>
            </footer>
        </div>
        <!--/.fluid-container-->

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>