<?php
	// Starting session
	session_start();
	if(!isset($_SESSION["orukonla"]))
	{
    	//header("location:../login.php"); 
		header("location:logout.php");
	}
?>