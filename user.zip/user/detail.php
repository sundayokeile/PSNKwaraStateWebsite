<?php
	require_once("db_connection.php");
	require_once ("admin_session.php");
?>
<!DOCTYPE html>
<html>
    
    <head>
        <title>Member :: Details...</title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <link href="assets/DT_bootstrap.css" rel="stylesheet" media="screen">
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="vendors/flot/excanvas.min.js"></script><![endif]-->
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="#">PROFILE</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> <?php echo strtoupper($_SESSION['orukonla']); ?> <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="logout.php">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Payment <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="dues.php">Save Payment</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="my_dues.php">Payment History</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Members <i class="caret"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="dir_member.php">Member List</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">Update Profile</a>
                                    </li>
                                    
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse"><li class="active">
                            <a href="dir_member.php"><i class="icon-chevron-right"></i> Member Directory</a>
                        </li>
                        <li>
                            <a href="dir_dues.php"><i class="icon-chevron-right"></i> Payment History</a>
                        </li>
                        <li>
                            <a href="manage.php"><i class="icon-chevron-right"></i> Manage Admin Account</a>
                        </li>  
                        <li>
                            <a href="mimeupload.php"><!--span class="badge badge-success pull-right">731</span--> Minutes of Meeting</a>
                        </li>
                         <li>
                            <a href="bulletin.php"> Add News Bulletin</a>
                        </li>
                        <li>
                            <a href="logout.php"><i class="icon-chevron-right"></i> Logout</a>
                        </li>
                    </ul>
                </div>
                <!--/span-->
                <div class="span9" id="content">
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">                       
                        <?php
						if(isset($_GET['username']))
						{
							$username = $_GET['username'];
							
							$query = mysqli_query($db,"SELECT * FROM tbl_member WHERE username ='$username'") or die( mysql_error() );
						}
							while($row = mysqli_fetch_assoc($query))
							{
								//$p = $row['Patientid'];
							echo'
								 <div class="navbar navbar-inner block-header">
									<div class="muted pull-left"><span class="badge badge-info">1</span> MEMBER PROFILE: <strong>'.$row['title'].' '.$row['surname'].'</strong> </div>
										<!-- <div class="pull-right">
											<a href="editreg.php?'.$row['username'].'">
												<button class="btn btn-info">
													Edit Biodata
												</button>
											</a>
										</div> 
										<div class="btn-group pull-right">
                                        	<button data-toggle="dropdown" class="btn dropdown-toggle">Task List <span class="caret"></span></button>
                                         	<ul class="dropdown-menu">
                                            	<li><a href="viewvitalsigns.php?Patientid='.$row['username'].'">Vital Signs</a></li>
                                            	<li><a href="viewreport.php?Patientid='.$row['username'].'">Lab Reports</a></li>
                                            	<li><a href="editreg.php?Patientid='.$row['username'].'">Radiology Reports</a></li>
												<li><a href="viewhistory.php?Patientid='.$row['username'].'">Medical Records</a></li>
												<li><a href="editreg.php?Patientid='.$row['username'].'">Edit Basic Info</a></li>
                	                        </ul>
										</div>-->
															 
									</div>	
								<div class="block-content collapse in">
									<div class="span10">
										<table class="table table-hover table-bordered">
										  <thead>
											<tr>
											  <th>Title</th>
											  <th>Surname</th>
											  <th>Firstname</th>
											  <th>Lastname</th>
											</tr>
										  </thead>
										  <tbody>
											<tr class="info">
											  <td>'.$row['title'].'</td>
											  <td>'.$row['surname'].'</td>
											  <td>'.$row['firstname'].'</td>
											  <td>'.$row['lastname'].'</td>
											</tr>
										  </tbody>
										</table>
									</div>
								</div>
							</div>
							<!-- /block -->
						</div>
	
						<div class="row-fluid">
							<!-- block -->
							<div class="block">
								<div class="navbar navbar-inner block-header">
									<div class="muted pull-left"><span class="badge badge-info">2</span></div>
								</div>
								<div class="block-content collapse in">
									<div class="span10">
										<table class="table table-hover table-bordered">
										  <thead>
											<tr>
											  <th>Sex</th>
											  <th>PCN Reg.No</th>
											  <th>Phone No</th>
											  <th>Other No</th>
											  <th>DOB</th>
											</tr>
										  </thead>
										  <tbody>
											<tr class="info">
											  <td>'.$row['sex'].'</td>
											  <td>'.$row['pcnregno'].'</td>
											  <td>'.$row['phoneno'].'</td>
											  <td>'.$row['alternateno'].'</td>
											  <td>'.$row['dateofbirth'].'</td>
											</tr>
										  </tbody>
										</table>
									</div>
								</div>
							</div>
							<!-- /block -->
						</div>
	
						<div class="row-fluid">
							<!-- block -->
							<div class="block">
								<div class="navbar navbar-inner block-header">
									<div class="muted pull-left"><span class="badge badge-info">3</span></div>
								</div>
								<div class="block-content collapse in">
									<div class="span10">
										<table class="table table-hover table-bordered">
										  <thead>
											<tr class="info">
											  <th>Email</th>
											  <th>Home Address</th>
											  <th>Office Address</th>
											  <th>Marital Status</th>
											</tr>
										  </thead>
										  <tbody>
											<tr class="info">
											  <td>'.$row['email'].'</td>	
											  <td>'.$row['homeaddress'].'</td>
											  <td>'.$row['officeaddress'].'</td>
											  <td>'.$row['maritalstatus'].'</td>
											</tr>
										  </tbody>
										</table>
									</div>
								</div>
							</div>
							<!-- /block -->
						</div><!-- row-fluid->
						
						<div class="row-fluid">
							<!-- block -->
							<div class="block">
								<div class="navbar navbar-inner block-header">
									<div class="muted pull-left"><span class="badge badge-info">4</span></div>
								</div>
								<div class="block-content collapse in">
									<div class="span10">
										<table class="table table-hover table-bordered">
										  <thead>	
											<tr class="info">
											  <th>Wedding Anni</th>
											  <th>Technical Group</th>
											  <th>Interest Group</th>
											  <th>School Attended</th>
											  <th>Year Graduated</th>
											</tr>
										  </thead>
										  <tbody>
											<tr class="info">
											  <td>'.$row['wedanni'].'</td>	
											  <td>'.$row['technicalgroup'].'</td>
											  <td>'.$row['interestgroup'].'</td>
											  <td>'.$row['schoolattended'].'</td>
											  <td>'.$row['yearofgraduation'].'</td>
											</tr>
										  </tbody>
										</table>
									</div>
								</div>
							</div>
							<!-- /block -->
						</div><!-- row-fluid->
						
						
					</div>
				</div>
				<hr>
					';
			}
					//}
        ?>
						              
            <footer>
              <p>&copy; <?php  date_default_timezone_set("Africa/Lagos");echo date('Y'); ?>. All Rights Reserved | PSN KWARA STATE</p>
            </footer>
        </div>
        <!--/.fluid-container-->

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>