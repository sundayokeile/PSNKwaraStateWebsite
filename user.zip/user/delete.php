<?php 
	require_once('admin_session.php');
	require_once('db_connection.php');
	
	$pathname= $_GET['pathname'];
	//echo $name;
	
	$res=mysqli_query($db, "SELECT pdfinput FROM tbl_minutes WHERE pathname='$pathname'");
	
	$row=mysqli_fetch_array($res);
	
	mysqli_query($db, "DELETE FROM tbl_minutes WHERE pathname='$pathname'");
	
	unlink($pathname);
	
	header("Location:mimeupload.php");
?>