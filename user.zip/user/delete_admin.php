<?php 
	require_once('admin_session.php');
	require_once('db_connection.php');
	
	if(isset($_GET['username']))
	{
		$username = $_GET['username'];
		$select = mysqli_query($db, "delete from tbl_admin where username = '$username' ");
		header("location:manage.php");
	}
?>