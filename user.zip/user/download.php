<?php
require_once('session.php');
require_once('db_connection.php');
	
	//$pathname= $_GET['pathname'];
	$name= $_GET['pathname'];
    header('Content-Description: File Transfer');
    header('Content-Type: application/force-download');
    header("Content-Disposition: attachment; filename=\"uploadpdf" .basename($name) . "\";");
	//header("Content-Disposition: attachment; filename=\$pathname");
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($name));
    //header('Content-Length: ' . filesize($pathname));
    ob_clean();
    flush();
	readfile($name);
    //readfile($pathname); //showing the path to the server where the file is to be download
    exit;
?>