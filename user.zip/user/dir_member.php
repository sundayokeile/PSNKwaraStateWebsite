<?php 
	require_once('admin_session.php');
	require_once('db_connection.php');
?>
<!DOCTYPE html>
<html>
    
    <head>
        <title>Member - Directory</title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <link href="assets/DT_bootstrap.css" rel="stylesheet" media="screen">
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="vendors/flot/excanvas.min.js"></script><![endif]-->
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="#">PROFILE</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> <?php echo strtoupper($_SESSION['orukonla']); ?> <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="logout.php">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
                            
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Payment <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Something</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="dir_dues.php">Payment History</a>
                                    </li>
                                    
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Members <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Member List</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">Something</a>
                                    </li>
                                    
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse"><li class="active">
                            <a href="#"><i class="icon-chevron-right"></i> Member Directory</a>
                        </li>
                        <li>
                            <a href="dir_dues.php"><i class="icon-chevron-right"></i> Payment History</a>
                        </li>
                        <li>
                            <a href="manage.php"><i class="icon-chevron-right"></i> Manage Admin Account</a>
                        </li>  
                        <li>
                            <a href="mimeupload.php"><i class="icon-chevron-right"></i> Minutes of Meeting</a>
                        </li>
                        <li>
                            <a href="bulletin.php"><i class="icon-chevron-right"></i> Add News Bulletin</a>
                        </li>
                        <li>
                            <a href="logout.php"><i class="icon-chevron-right"></i> Logout</a>
                        </li>
                    </ul>
                </div>
                <!--/span-->
                <div class="span9" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">PSN: KWARA STATE - Member Directory</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                   <div class="table-toolbar">
                                      <div class="btn-group">
                                         <a href="addmember.php"><button class="btn btn-success"> ADD NEW MEMBER<i class="icon-plus icon-white"></i></button> </a>                                     </div>
                                      <div class="btn-group pull-right">
                                         <button data-toggle="dropdown" class="btn dropdown-toggle">Tools <span class="caret"></span></button>
                                         <ul class="dropdown-menu">
                                            <!--<li><a href="#">Print</a></li>-->
                                            <li><a href="psnmember.php" target="_blank">Save as PDF</a></li>
                                            <!--<li><a href="#">Export to Excel</a></li>-->
                                         </ul>
                                      </div>
                                   </div>
                                    
                                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example2">
                                        <thead>
                                        <!--to display search textbox, the number of tag th must equal tag <td>-->
                                            <tr>
                                                <th>Id</th>
                                                <th>Name</th>
                                                <th>Technical group</th>
                                                <th>Phone No</th>
                                                <th>Email</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
											<?php
												$sql2 = "select * from tbl_member";
												$sql2 .= " order by surname asc";
												$sql_query = mysqli_query($db, $sql2);
												$count = 0;
												//echo $count;
												while( $row = mysqli_fetch_array( $sql_query ) )
												{
													$name = strtoupper($row['title']." ".$row['surname']. " ".$row['firstname'] );
													echo '
														<tr class="gradeC">
															<td>'.++$count.'</td>
															<td>'.$name.'</td>
															<td>'.$row['technicalgroup'].'</td>
															<td>'.$row['phoneno'].'</td>
															<td>'.$row['email'].'</td>
															<td> 
																<a href="detail.php?username='.$row['username'].'">
																 	<button class="btn btn-primary">Profile</button>
																</a>
															 </td>
														</tr>';
												}
											?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
            <hr>
            <footer>
                <p>&copy; <?php  date_default_timezone_set("Africa/Lagos");echo date('Y'); ?>. All Rights Reserved | PSN KWARA STATE</p>
            </footer>
        </div>
        <!--/.fluid-container-->

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>