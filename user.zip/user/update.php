<?php 
	require_once('session.php');
	require_once('db_connection.php');
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Member - Update</title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="vendors/flot/excanvas.min.js"></script><![endif]-->
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
   <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="my_member.php">DASHBOARD</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> <?php echo strtoupper($_SESSION['orukonaa']); ?> <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="profile.php">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="logout.php">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Payment <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="dues.php">Save Payment</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="my_dues.php">Payment History</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Members <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="my_member.php">Member List</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">Update Profile</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse"><li>
                            <a href="dues.php"><i class="icon-chevron-right"></i> Save Payment</a>
                        </li>
                        <li>
                            <a href="my_dues.php"><i class="icon-chevron-right"></i> Payment History</a>
                        </li>
                        <li>
                            <a href="my_member.php"><i class="icon-chevron-right"></i> Member Directory</a>
                        </li>
                        <li>
                            <a href="profile.php"><i class="icon-chevron-right"></i> My Profile</a>
                        </li>
                        <li class="active">
                            <a href="#"><i class="icon-chevron-right"></i> Update Profile</a>
                        </li>
                        <li>
                            <a href="mime.php"><!--span class="badge badge-success pull-right">731</span--> Minutes of Meeting</a>
                        </li>
                        <li>
                            <a href="logout.php"><i class="icon-chevron-right"></i> Logout</a>
                        </li>
                        
                    </ul>
                </div>
                <!--/span-->
                <?php
                	$username = $_SESSION['orukonaa'];
					$get_rcd = mysqli_query($db, "SELECT * FROM tbl_member WHERE username = '$username'");
					$row = $get_rcd->fetch_array();
				?>
                <div class="span9" id="content">
                     <!-- validation -->
                    <div class="row-fluid">
                         <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Update My-Profile</div>
                            </div>
                            <div class="block-content collapse in">
                            	<div class="span12">
                                	<!--update script begins-->
                                    <?php
										if(isset($_POST['update']))
										{
											$title = $_POST['title'];
											$surname = $_POST['surname'];
											$firstname = $_POST['firstname'];
											$lastname = $_POST['lastname'];
											$sex = $_POST['sex'];
											$dateofbirth = $_POST['dateofbirth'];
											$maritalstatus = $_POST['maritalstatus'];
											$wedanni = $_POST['wedanni'];
											$homeaddress = $_POST['homeaddress'];
											$officeaddress = $_POST['officeaddress'];
											$phoneno = $_POST['phoneno'];
											$alternateno = $_POST['alternateno'];
											$email = $_POST['email'];
											$technicalgroup = $_POST['technicalgroup'];
											$interestgroup = $_POST['interestgroup']; 	
											$schoolattended = $_POST['schoolattended'];
											$yearofgraduation = $_POST['yearofgraduation'];
											$password = $_POST['password'];
											//$username = $_SESSION['orukonaa'];
											$update = "UPDATE tbl_member SET title='$title', surname='$surname', firstname ='$firstname', lastname='$lastname', sex='$sex', dateofbirth='$dateofbirth', maritalstatus='$maritalstatus', wedanni='$wedanni', homeaddress='$homeaddress', officeaddress='$officeaddress', phoneno='$phoneno', alternateno='$alternateno', email='$email', technicalgroup='$technicalgroup', interestgroup='$interestgroup', schoolattended='$schoolattended', yearofgraduation='$yearofgraduation', password = '$password' WHERE username = '$username'";
											if ($db->query($update) === TRUE)
											{
												$msg = "Record updated successfully";
											}
											else
											{
												$msg = "Error updating record: " . $db->error;
											}
											$db->close();
										}
									?>
                                    <!--update script ends -->
                                     <?php 
										if(isset($_POST['update']))
										{
											echo "<div class='alert alert-success' role='alert'>
													$msg
												</div>";
										}
									?>
                                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="form-horizontal">
                                    	<!--php script fetch begins-->
                                    	<?php
											/*$username = $_SESSION['orukonaa'];
											$get_rcd = mysqli_query($db, "SELECT * FROM tbl_member WHERE username = '$username'");
											if($row = $get_rcd->fetch_array())
											{
												$msg =  "Member Profile not found!";
											}
											else //if record found, paste and update record...
											{*/
												echo'
													<div class="control-group">
														<label class="control-label" for="focusedInput">Title</label>
														<div class="controls">
															<input class="input-xlarge focused" name="title" type="text" value="'.$row['title'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">Surname</label>
														<div class="controls">
															<input class="input-xlarge focused" name="surname" type="text" value="'.$row['surname'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">Firstname</label>
														<div class="controls">
															<input class="input-xlarge focused" name="firstname" type="text" value="'.$row['firstname'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">Lastname</label>
														<div class="controls">
															<input class="input-xlarge focused" name="lastname" type="text" value="'.$row['lastname'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="select01">Sex</label>
														<div class="controls">
															<select name="sex" class="chzn-select">
															  <option value="'.$row['sex'].'">'.$row['sex'].'</option>
															  <option>Female</option>
															  <option>Male</option>
															</select>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="date01">Date of Birth</label>
														<div class="controls">
															<input type="text" name="dateofbirth" class="input-xlarge datepicker" value="'.$row['dateofbirth'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="select01">Marital Status</label>
														<div class="controls">
															<select name="maritalstatus" class="chzn-select">
															  <option value="'.$row['maritalstatus'].'">'.$row['maritalstatus'].'</option>
															  <option>Single</option>
															  <option>Married</option>
															</select>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="date01">Wedding Anni</label>
														<div class="controls">
															<input type="text" name="wedanni" class="input-xlarge datepicker" value="'.$row['wedanni'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="textarea2">Home Address</label>
														<div class="controls">
															<textarea name="homeaddress" class="input-xlarge textarea" style="width: 500px; height: 100">'.$row['homeaddress'].'</textarea>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="textarea2">Office Address</label>
														<div class="controls">
															<textarea name="officeaddress" class="input-xlarge textarea" style="width: 500px; height: 100">'.$row['officeaddress'].'</textarea>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">phone No</label>
														<div class="controls">
															<input class="input-xlarge focused" name="phoneno" type="text" value="'.$row['phoneno'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">Alternate No</label>
														<div class="controls">
															<input class="input-xlarge focused" name="alternateno" type="text" value="'.$row['alternateno'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">Email</label>
														<div class="controls">
															<input class="input-xlarge focused" name="email" type="text" value="'.$row['email'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">Technical Group</label>
														<div class="controls">
															<input class="input-xlarge focused" name="technicalgroup" type="text" value="'.$row['technicalgroup'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">Interest Group</label>
														<div class="controls">
															<input class="input-xlarge focused" name="interestgroup" type="text" value="'.$row['interestgroup'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">School Attended</label>
														<div class="controls">
															<input class="input-xlarge focused" name="schoolattended" type="text" value="'.$row['schoolattended'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">Graduation Year</label>
														<div class="controls">
															<input class="input-xlarge focused" name="yearofgraduation" type="text" value="'.$row['yearofgraduation'].'" required>
														</div>
													</div>
													<div class="control-group">
														<label class="control-label" for="focusedInput">Password</label>
														<div class="controls">
															<input class="input-xlarge focused" name="password" type="text" value="'.$row['password'].'" required>
														</div>
													</div>
													<div class="form-actions">
														<button type="submit" name="update" class="btn btn-primary">Update</button>
														<button type="reset" class="btn">Cancel</button>
													</div>
													</fieldset>
												';
											//}  
                            
										?>
                                        <!--php script fetch end-->
                                    </form>
                       			</div>
							</div>		
						</div>
                     	<!-- /block -->
					</div>
                     <!-- /validation -->
                </div>
            </div>
            <hr>
            <footer>
                <p>&copy; <?php  date_default_timezone_set("Africa/Lagos");echo date('Y'); ?>. All Rights Reserved | PSN KWARA STATE</p>
            </footer>
        </div>
        <!--/.fluid-container-->
        <link href="vendors/datepicker.css" rel="stylesheet" media="screen">
        <link href="vendors/uniform.default.css" rel="stylesheet" media="screen">
        <link href="vendors/chosen.min.css" rel="stylesheet" media="screen">

        <link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/jquery.uniform.min.js"></script>
        <script src="vendors/chosen.jquery.min.js"></script>
        <script src="vendors/bootstrap-datepicker.js"></script>

        <script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
        <script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

        <script src="vendors/wizard/jquery.bootstrap.wizard.min.js"></script>

	<script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
	<script src="assets/form-validation.js"></script>
        
	<script src="assets/scripts.js"></script>
        <script>

	jQuery(document).ready(function() {   
	   FormValidation.init();
	});
	

        $(function() {
            $(".datepicker").datepicker();
            $(".uniform_on").uniform();
            $(".chzn-select").chosen();
            $('.textarea').wysihtml5();

            $('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.bar').css({width:$percent+'%'});
                // If it's the last tab then hide the last button and show the finish instead
                if($current >= $total) {
                    $('#rootwizard').find('.pager .next').hide();
                    $('#rootwizard').find('.pager .finish').show();
                    $('#rootwizard').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#rootwizard').find('.pager .next').show();
                    $('#rootwizard').find('.pager .finish').hide();
                }
            }});
            $('#rootwizard .finish').click(function() {
                alert('Finished!, Starting over!');
                $('#rootwizard').find("a[href*='tab1']").trigger('click');
            });
        });
        </script>
    </body>

</html>