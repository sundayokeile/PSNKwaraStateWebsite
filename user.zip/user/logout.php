<?php
	session_start(); //Start the current session
	unset($_SESSION['orukonaa']);
	unset($_SESSION['orukonla']);
	session_destroy(); //Destroy it! So we are logged out now
	//header("Location:../index.php?msg=You are Logged out"); // Move back to login.php with a logout message
	header("Location:../index.php");
?>
