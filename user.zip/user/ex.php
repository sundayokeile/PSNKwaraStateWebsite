<?php
require('mysql_table.php');

class PDF extends PDF_MySQL_Table
{
	function Header()
	{
		// Logo
		$this->Image('tablogo.png',10,6,30);
		// Arial bold 15
		$this->SetFont('Arial','B',15);
		// Move to the right
		//$this->Cell(40);
		$this->Cell(40);
		$this->Ln(10);
		//Title
		$this->SetFont('Arial','',18);
		$this->Cell(0,6,'Pharmaceutical Society of Nigeria',0,1,'C');
		$this->Cell(0,6,'Kwara State Chapter',0,1,'C');
		$this->SetFont('Arial','',10);
		$this->Cell(0,6,'Ahmadu Bello Road, Ilorin, Kwara State',0,1,'C');
		$this->SetFont('Arial','',8);
		$this->Cell(0,6,'+234 906 469 6450. +234 803 376 3534.',0,1,'C');
		$this->SetFont('Arial','',12);
		$this->Cell(0,6,'PSN MEMBER LIST',0,1,'C');
		$this->Ln(5);
		//Ensure table header is output
		parent::Header();
	}
}

//Connect to database
$db = new mysqli('localhost', 'root', 'root', 'dbpsnkwara');


$pdf=new PDF();
$pdf->AddPage();
//First table: put all columns automatically
$pdf->AddCol('title',15,'Title','L');
$pdf->AddCol('surname',20,'Surname');
$pdf->AddCol('technicalgroup',15,'Tech.Grp');
$pdf->AddCol('phoneno',20,'Phone No');
$pdf->AddCol('email',25,'Email','R');
$prop=array('HeaderColor'=>array(255,150,100),
			'color1'=>array(210,245,255),
			'color2'=>array(255,255,210),
			'padding'=>2);
$pdf->Table('select title, surname, technicalgroup, phoneno, email from tbl_member order by username', $prop);
$pdf->Output();
?>
