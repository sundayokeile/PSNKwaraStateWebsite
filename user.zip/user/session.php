<?php
	// Starting session
	session_start();
	if(!isset($_SESSION["orukonaa"]))
	{
    	//header("location:../login.php"); 
		header("location:logout.php");
	}
?>