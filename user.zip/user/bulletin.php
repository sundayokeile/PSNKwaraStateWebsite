<?php 
	require_once('admin_session.php');
	require_once('db_connection.php');
?>
<!DOCTYPE html>
<html>
    
    <head>
        <title>Bulletin List...</title>
        <!-- Bootstrap -->
         <link rel="stylesheet" type="text/css" href="vendors/bootstrap-wysihtml5/src/bootstrap-wysihtml5.css"></link>
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <link href="assets/DT_bootstrap.css" rel="stylesheet" media="screen">
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="vendors/flot/excanvas.min.js"></script><![endif]-->
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>    
    <body>
    
         <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="#">PROFILE</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> <?php echo strtoupper($_SESSION['orukonla']); ?> <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="logout.php">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
                            
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Payment <i class="caret"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Something</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="dir_dues.php">Payment History</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Members <i class="caret"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Member List</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">Something</a>
                                    </li>
                                    
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse"><li>
                            <a href="dir_member.php"><i class="icon-chevron-right"></i> Member Directory</a>
                        </li>
                        <li>
                            <a href="dir_dues.php"><i class="icon-chevron-right"></i> Payment History</a>
                        </li>
                        <li>
                            <a href="manage.php"><i class="icon-chevron-right"></i> Manage Admin Account</a>
                        </li>  
                        <li>
                            <a href="mimeupload.php"><i class="icon-chevron-right"></i> Minutes of Meeting</a>
                        </li>
                        <li class="active">
                            <a href="#"><i class="icon-chevron-right"></i> Add News Bulletin</a>
                        </li>
                        <li>
                            <a href="logout.php"><i class="icon-chevron-right"></i> Logout</a>
                        </li>
                        
                    </ul>
                </div>
                <!--/span-->
                <div class="span9" id="content">
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Upload News Bulletin...</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                	<?php
										if(isset($_POST["insert"]))
										{
											 $targetfolder = "news_img/";
					 
											 $targetfolder = $targetfolder . basename( $_FILES['file']['name']) ;
											 
											 $ok = 1;
											 //$date = $_POST['date'];
											 date_default_timezone_set("Africa/Lagos"); 
                                    		 $datesaved = date('d/F/Y');
											 $headline = $_POST['headline'];
											 $content = $_POST['content'];
											 $postby = $_POST['postby'];	 
											 $file_type=$_FILES['file']['type'];
											 if ($file_type=="image/gif" || $file_type=="image/jpeg")
											 // || $file_type=="image/gif" || $file_type=="image/jpeg" ||		 $file_type=="application/msword")
											 {
												 if(move_uploaded_file($_FILES['file']['tmp_name'], $targetfolder))
												 {
													 //$pathname = "news_img/" . basename( $_FILES['file']['name']);
													$img_news = "user/news_img/" . basename( $_FILES['file']['name']);
													$img_bulletin =  "news_img/".basename( $_FILES['file']['name']);
													 
													// echo "The file ". basename( $_FILES['file']['name']). " is uploaded";
													 try
													 {
														 $compare = mysqli_query($db, "select img_bulletin from tbl_bulletin where img_bulletin ='$img_bulletin'");
														 if ($row = $compare->fetch_assoc())
														 {
															 $msg =  "File Already Exist, Duplication is not allowed!";
														 }
														 else// if record not found, insert new record...
														 {
															 $insert = mysqli_query($db, "INSERT INTO tbl_bulletin(date, img_news, img_bulletin, headline, content, postby) VALUES('$datesaved', '$img_news', '$img_bulletin', '$headline', '$content', '$postby' )") or die(mysqli_error($db) );
															 if($insert)
															 {
																 $msg = "The News is uploaded!";
														 	 }
														 	 else
														 	 {
																 $msg = "Someting went wrong!";
															 }
														 }
													 }
													 catch(exception $e){ echo "<p>".$e->getMessage()."</p>"; }
												 }
												 else
												 {
													$msg = "Problem uploading file";
												 }
											}
											else
											{
												$msg = "You may only upload gif or jpeg files";
											}
										}
									?>
                                	<!-- BEGIN FORM-->
                                    <?php 
										if(isset($_POST['insert']))
										{
											echo "<div class='alert alert-success' role='alert'>
													$msg
												</div>";
										}
									?>	
  									<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" class="form-horizontal" enctype="multipart/form-data">
                                    	<!--<div class="control-group">
                                        	<label class="control-label" for="focusedInput">Title</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="title" type="text" value="" required>
                                            </div>
                                        </div>-->
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Select File</label>
                                          <div class="controls">
                                            <input class="input-file uniform_on" name="file" type="file" required>
                                          </div>
                                        </div> 
                                        <div class="control-group">
                                        	<label class="control-label" for="focusedInput">Headline</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="headline" type="text" value="" required>
                                            </div>
                                        </div>   
                                        <!--<div class="control-group">
                                        	<label class="control-label" for="focusedInput">Content</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="content" type="text" value="" required>
                                            </div>
                                        </div>-->
                                        <div class="container-fluid">
                                      		<div class="span10">
                								<div class="row-fluid">
                                        			<div class="span12" id="content">
                                            			<div class="row-fluid">
                                                            <!-- block -->
                                                            <div class="block">
                                                                <div class="navbar navbar-inner block-header">
                                                                    <div class="muted pull-left">Bulletin Body</div>
                                                                </div>
                                                                <div class="block-content collapse in">
                                                                   <textarea name="content" id="bootstrap-editor" placeholder="Enter text here ..." style="width:90%;height:400px;"></textarea>
                                                                </div>
                                                            </div>
                                                            <!-- /block -->
                                                        </div>
		               					 			</div>
                                         		</div>
											</div>
										</div>
                                         
                                        <div class="control-group">
                                        	<label class="control-label" for="focusedInput">Post By</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="postby" type="text" value="" required>
                                            </div>
                                        </div>      
                                        <div class="form-actions">
                                        	<button type="submit" name="insert" class="btn btn-primary">INSERT</button>
                                            <button type="reset" class="btn">Cancel</button>
                                        </div>
                                        </fieldset>
                                    </form>
                                    <!-- END FORM-->
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">News Bulletin Lists...</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                   <div class="table-toolbar">
                                      <div class="btn-group">
                                         <a href="#"><button class="btn btn-success"> <i class="icon-list icon-list"></i></button></a>
                                      </div>
                                      <!--<div class="btn-group pull-right">
                                         <button data-toggle="dropdown" class="btn dropdown-toggle">Tools <span class="caret"></span></button>
                                         <ul class="dropdown-menu">
                                            <li><a href="#">Print</a></li>
                                            <li><a href="#">Save as PDF</a></li>
                                            <li><a href="#">Export to Excel</a></li>
                                         </ul>
                                      </div>-->
                                   </div>
                                    <!--<div><img src="news_img/dele in Church.jpg" class="img-responsive" alt="" /></div>-->
                                    <!--php script end-->
<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-hover" id="example2">
                                        <thead>
                                        <!--to display search textbox, the number of tag th must equal tag <td>-->
                                            <tr>
                                                <th>Id</th>
                                                <th>Date</th>
                                                <th>Image</th>
                                                <th>Headline</th>
                                              <th>Postby</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
											<?php
												$user_id = $_SESSION['orukonla'];
												$sql2 = "select id, date, img_bulletin, headline, postby from tbl_bulletin";
												$sql2 .= " order by date desc";
												$sql_query = mysqli_query($db, $sql2);
												
												//echo "<img src='$show_img' class='img-responsive' alt='' />";
												while( $row = mysqli_fetch_array( $sql_query ) )
												{
													$show_img = $row['img_bulletin'];
													echo'
														<tr class="gradeC">
															<td>'.$row['id'].'</td>
															<td>'.$row['date'].'</td>
														';
													echo"
															<td width='10%' height='10%'><img src='$show_img' class='img-responsive' alt=''></td>";												
													echo'
															<td>'.$row['headline'].'</td>
															<td>'.$row['postby'].'</td>
															<td> 
																<a href="delete_bulletin.php?img_bulletin='.$row['img_bulletin'].'">
																 	<button class="btn btn-success">Delete</button>
																</a>
															 </td>
														</tr>';
												}
											?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
            <hr>
            <footer>
                <p>&copy; <?php  date_default_timezone_set("Africa/Lagos");echo date('Y'); ?>. All Rights Reserved | PSN KWARA STATE</p>
            </footer>
        </div>
        <!--/.fluid-container-->

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
        <!--/.fluid-container-->
        <script src="vendors/bootstrap-wysihtml5/lib/js/wysihtml5-0.3.0.js"></script>
        <script src="vendors/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
		<script src="vendors/bootstrap-wysihtml5/src/bootstrap-wysihtml5.js"></script>

		<script src="vendors/ckeditor/ckeditor.js"></script>
		<script src="vendors/ckeditor/adapters/jquery.js"></script>

		<script type="text/javascript" src="vendors/tinymce/js/tinymce/tinymce.min.js"></script>

        <script src="assets/scripts.js"></script>
        <script>
        $(function() {
            // Bootstrap
            $('#bootstrap-editor').wysihtml5();

            // Ckeditor standard
            $( 'textarea#ckeditor_standard' ).ckeditor({width:'98%', height: '150px', toolbar: [
				{ name: 'document', items: [ 'Source', '-', 'NewPage', 'Preview', '-', 'Templates' ] },	// Defines toolbar group with name (used to create voice label) and items in 3 subgroups.
				[ 'Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo' ],			// Defines toolbar group without name.
				{ name: 'basicstyles', items: [ 'Bold', 'Italic' ] }
			]});
            $( 'textarea#ckeditor_full' ).ckeditor({width:'98%', height: '150px'});
        });

        // Tiny MCE
        tinymce.init({
		    selector: "#tinymce_basic",
		    plugins: [
		        "advlist autolink lists link image charmap print preview anchor",
		        "searchreplace visualblocks code fullscreen",
		        "insertdatetime media table contextmenu paste"
		    ],
		    toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
		});

		// Tiny MCE
        tinymce.init({
		    selector: "#tinymce_full",
		    plugins: [
		        "advlist autolink lists link image charmap print preview hr anchor pagebreak",
		        "searchreplace wordcount visualblocks visualchars code fullscreen",
		        "insertdatetime media nonbreaking save table contextmenu directionality",
		        "emoticons template paste textcolor"
		    ],
		    toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		    toolbar2: "print preview media | forecolor backcolor emoticons",
		    image_advtab: true,
		    templates: [
		        {title: 'Test template 1', content: 'Test 1'},
		        {title: 'Test template 2', content: 'Test 2'}
		    ]
		});

        </script>
    </body>

</html>