<?php 
	require_once('session.php');
	require_once('db_connection.php');
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Member - Dues</title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="vendors/flot/excanvas.min.js"></script><![endif]-->
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
   <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="my_member.php">DASHBOARD</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> <?php echo strtoupper($_SESSION['orukonaa']); ?> <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="profile.php">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="logout.php">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
                            
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Payment <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Save Payment</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="my_dues.php">Payment History</a>
                                    </li>
                                    
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Members <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="my_member.php">Member List</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="update.php">Update Profile</a>
                                    </li>
                                    
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                    	<li class="active">
                            <a href="#"><i class="icon-chevron-right"></i> Save Payment</a>
                        </li>
                        <li>
                            <a href="my_dues.php"><i class="icon-chevron-right"></i> Payment History</a>
                        </li>
                        <li>
                            <a href="my_member.php"><i class="icon-chevron-right"></i> Member Directory</a>
                        </li>
                        <li>
                            <a href="profile.php"><i class="icon-chevron-right"></i> My Profile</a>
                        </li>
                        <li>
                            <a href="update.php"><i class="icon-chevron-right"></i> Update Profile</a>
                        </li>
                        <li>
                            <a href="mime.php"><!--span class="badge badge-success pull-right">731</span--> Minutes of Meeting</a>
                        </li>
                        <li>
                            <a href="logout.php"><i class="icon-chevron-right"></i> Logout</a>
                        </li>
                        
                    </ul>
                </div>
                <!--/span-->
                <div class="span9" id="content">
                     <!-- validation -->
                    <div class="row-fluid">
                         <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Save New Payment</div>
                            </div>
                            <!--php script begins-->
							<?php
                                if(isset($_POST['submit']))
                                {
									$name = $_POST["name"];
                                    $bankname = $_POST["bankname"];
                                    $tellerno = $_POST["tellerno"];
                                    $paymentdate = $_POST["paymentdate"];
                                    $dues = $_POST["dues"];
                                    $amount = $_POST["amount"];
									$username = $_SESSION['orukonaa'];
									date_default_timezone_set("Africa/Lagos"); 
                                    $datesaved = date('m/d/Y');
									$datesaved = $datesaved;                                    
									
									$compare = mysqli_query($db, "SELECT tellerno FROM tbl_dues WHERE tellerno = '$tellerno'");
                                    if ($row = $compare->fetch_assoc())
                                    {
                                        $msg =  "Payment Duplicate Not Allowed!";
                                    }
                                    else// if record not found, insert new record...
                                    {
										if (!preg_match("/^[a-zA-Z ]*$/",$name))
										{
											$msg = "Oops!, somethong went wrong: Name";
										}
										elseif (!preg_match("/^[a-zA-Z ]*$/",$bankname))
										{
											$msg = "Oops!, somethong went wrong: Bankname";
										}
										elseif (preg_match("/^[a-zA-Z ]*$/",$tellerno))
										{
											$msg = "Oops!, somethong went wrong: Teller No";
										}
										elseif ($dues == "select")
										{
											$msg = "Oops!, Kindly make a selection: Dues";
										}
										elseif (preg_match("/^[a-zA-Z ]*$/",$amount))
										{
											$msg = "Oops!, somethong went wrong: Amount Paid";
										}
										else
										{
											$insert = "INSERT INTO tbl_dues VALUES('$name', '$bankname', '$tellerno', '$paymentdate', '$dues', '$amount', '$username', '$datesaved')";
											if($db->query($insert) === TRUE)
											{
												$msg = "New Payment Saved!";
											}
											else
											{
												$msg =  "Error: " . $insert . "<br>" . $db->error;
											}
										}
                                        $db->close();
                                    }
                                }
                            ?>
                            <!--php script end-->
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <!-- BEGIN FORM-->
                                    <?php 
										if(isset($_POST['submit']))
										{
											echo "<div class='alert alert-success' role='alert'>
													$msg
												</div>";
										}
									?>	
									<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" class="form-horizontal">
                                    	<div class="control-group">
                                        	<label class="control-label" for="select01">Dues</label>
                                        	<div class="controls">
                                                <select name="dues" class="chzn-select">
                                                  <option>select</option>
                                                  <option>PSN NATIONAL CAPITATION</option>
                                                  <option>ANNUAL DUE</option>
                                                  <option>ACPN</option>
                                                  <option>AHPN</option>
                                                  <option>NAIP</option>
                                                  <option>NAPA</option>
                                                  <option>ALPS</option>
                                                  <option>YPG</option>
                                                  <!--option>ALPS/YPG</option>
                                                  <option>NAPA</option-->
                                                  
                                                </select>
                                            </div>
                                        </div>
                                    	<div class="control-group">
                                        	<label class="control-label" for="focusedInput">Name</label>
                                            <div class="controls">
                                            	<input class="input-xlarge focused" name="name" type="text" value="" required>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                        	<label class="control-label" for="focusedInput">Bank Name</label>
                                         	<div class="controls">
                                         		<input class="input-xlarge focused" name="bankname" type="text" value="" required>
                                        	</div><span class="error">
                                        </div>
                                        <div class="control-group">
                                        	<label class="control-label">Teller No&nbsp;&nbsp;</label>
                                            <div class="controls">
                                            	<input name="tellerno" type="text" class="span6 m-wrap" required/>
                                                <!--span class="help-block">optional field</span-->
                                            </div>
                                        </div>
                                        
                                        <div class="control-group">
                                        	<label class="control-label" for="date01">Payment Date</label>
                                            <div class="controls">
                                            	<?php date_default_timezone_set("Africa/Lagos"); $date = date('m/d/Y')?>
                                            	<input type="text" name="paymentdate" class="input-xlarge datepicker" value="<?php echo $date;?>" required>
                                                <p class="help-block">Payment date is the date on the Bank Teller.</p>
                                        	</div>
                                        </div>              
                                        <div class="control-group">
                                        	<label class="control-label">Amount<span class="required">*</span></label>
                                            <div class="controls">
                                            	<input name="amount" type="text" class="span6 m-wrap" required/>
                                            </div>
                                        </div>
                                        <div class="form-actions">
                                        	<!--p class="help-block">Payment date is the date on the Bank Teller.</p>
                                            <p class="help-block">Payment date is the date on the Bank Teller.</p>
                                            <p class="help-block">Payment date is the date on the Bank Teller.</p-->
                                        </div>
                                        <div class="form-actions">
                                        	<button type="submit" name="submit" class="btn btn-primary">SAVE</button>
                                            <button type="reset" class="btn">Cancel</button>
                                        </div>
                                        </fieldset>
                                    </form>
                                    <!-- END FORM-->
								</div>
							</div>
						</div>
                     	<!-- /block -->
					</div>
                     <!-- /validation -->
                </div>
            </div>
            <hr>
            <footer>
                <p>&copy; <?php  date_default_timezone_set("Africa/Lagos");echo date('Y'); ?>. All Rights Reserved | PSN KWARA STATE</p>
            </footer>
        </div>
        <!--/.fluid-container-->
        <link href="vendors/datepicker.css" rel="stylesheet" media="screen">
        <link href="vendors/uniform.default.css" rel="stylesheet" media="screen">
        <link href="vendors/chosen.min.css" rel="stylesheet" media="screen">

        <link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/jquery.uniform.min.js"></script>
        <script src="vendors/chosen.jquery.min.js"></script>
        <script src="vendors/bootstrap-datepicker.js"></script>

        <script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
        <script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

        <script src="vendors/wizard/jquery.bootstrap.wizard.min.js"></script>

	<script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
	<script src="assets/form-validation.js"></script>
        
	<script src="assets/scripts.js"></script>
        <script>

	jQuery(document).ready(function() {   
	   FormValidation.init();
	});
	

        $(function() {
            $(".datepicker").datepicker();
            $(".uniform_on").uniform();
            $(".chzn-select").chosen();
            $('.textarea').wysihtml5();

            $('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.bar').css({width:$percent+'%'});
                // If it's the last tab then hide the last button and show the finish instead
                if($current >= $total) {
                    $('#rootwizard').find('.pager .next').hide();
                    $('#rootwizard').find('.pager .finish').show();
                    $('#rootwizard').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#rootwizard').find('.pager .next').show();
                    $('#rootwizard').find('.pager .finish').hide();
                }
            }});
            $('#rootwizard .finish').click(function() {
                alert('Finished!, Starting over!');
                $('#rootwizard').find("a[href*='tab1']").trigger('click');
            });
        });
        </script>
    </body>

</html>