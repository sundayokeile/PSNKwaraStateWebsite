<?php
	require_once('db_connection.php');
	session_start(); //Start the session
		error_reporting(-1);
		
	define(ADMIN,$_SESSION['orukonaa']); //Get the user name from the previously registered super global variable
	
	if(!session_is_registered("user"))
	{
		//If session not registered
		header("location:../login.php"); // Redirect to login.html page
	}
	
	else
		//Continue to current page
		header( 'Content-Type: text/html; charset=utf-8' );
?>
<?php
if(isset($_SESSION['orukonaa']))
{	
	$usename = $_SESSION['orukonaa'];
	$sql_uname = mysql_query("SELECT username FROM tbl_member WHERE username = '$usename'");
	$get = mysql_fetch_assoc($sql_uname);
	$name = $get['username'];
}
else
{
	include("logout.php");
}
?>