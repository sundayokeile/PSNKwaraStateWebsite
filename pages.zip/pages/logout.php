<?php
	session_start(); //Start the current session
	unset($_SESSION['orukonaa']);
	//session_destroy(); //Destroy it! So we are logged out now
	header("Location:../index.php?msg=You are Logged out"); // Move back to login.php with a logout message
?>
